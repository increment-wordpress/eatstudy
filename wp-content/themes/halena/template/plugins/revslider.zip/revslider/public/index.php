<?php // Silence is golden
?>